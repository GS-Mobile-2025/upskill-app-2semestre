import { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { Dashboard } from './components/Dashboard';
import { Profile } from './components/Profile';
import { JobsPage } from './components/JobsPage';
import { JobDetail } from './components/JobDetail';
import { RecommendationsPage } from './components/RecommendationsPage';

export type User = {
  id: string;
  name: string;
  email: string;
  role: string;
  skills: string[];
  experience: number;
  bio: string;
  avatar?: string;
};

export type Page = 'login' | 'signup' | 'dashboard' | 'profile' | 'jobs' | 'job-detail' | 'recommendations';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [user, setUser] = useState<User | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  const handleLogin = (email: string, password: string) => {
    // Mock login
    const mockUser: User = {
      id: '1',
      name: 'Maria Silva',
      email: email,
      role: 'Analista de Marketing',
      skills: ['Marketing Digital', 'SEO', 'Google Ads', 'Redes Sociais'],
      experience: 5,
      bio: 'Profissional de marketing com foco em estratégias digitais e análise de dados.',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop'
    };
    setUser(mockUser);
    setCurrentPage('dashboard');
  };

  const handleSignup = (name: string, email: string, password: string) => {
    // Mock signup
    const mockUser: User = {
      id: '1',
      name: name,
      email: email,
      role: 'Novo Usuário',
      skills: [],
      experience: 0,
      bio: 'Bem-vindo à plataforma!',
    };
    setUser(mockUser);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('login');
  };

  const handleViewJobDetail = (jobId: string) => {
    setSelectedJobId(jobId);
    setCurrentPage('job-detail');
  };

  const handleBack = () => {
    setCurrentPage('dashboard');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return (
          <LoginPage
            onLogin={handleLogin}
            onNavigateToSignup={() => setCurrentPage('signup')}
          />
        );
      case 'signup':
        return (
          <SignupPage
            onSignup={handleSignup}
            onNavigateToLogin={() => setCurrentPage('login')}
          />
        );
      case 'dashboard':
        return (
          <Dashboard
            user={user!}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
            onViewJob={handleViewJobDetail}
          />
        );
      case 'profile':
        return (
          <Profile
            user={user!}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
            onUpdateUser={setUser}
          />
        );
      case 'jobs':
        return (
          <JobsPage
            user={user!}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
            onViewJob={handleViewJobDetail}
          />
        );
      case 'job-detail':
        return (
          <JobDetail
            jobId={selectedJobId!}
            user={user!}
            onBack={handleBack}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
          />
        );
      case 'recommendations':
        return (
          <RecommendationsPage
            user={user!}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {renderPage()}
    </div>
  );
}
