import { Navigation } from './Navigation';
import { Page, User } from '../App';
import { MapPin, DollarSign, Clock, Users, TrendingUp, CheckCircle2, XCircle, ArrowLeft, Briefcase } from 'lucide-react';

type JobDetailProps = {
  jobId: string;
  user: User;
  onBack: () => void;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
};

const jobData = {
  id: '1',
  title: 'Analista de Marketing Digital Sênior',
  company: 'Tech Solutions',
  location: 'São Paulo, SP',
  salary: 'R$ 8.000 - R$ 12.000',
  match: 87,
  logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop',
  type: 'CLT',
  level: 'Sênior',
  postedDate: 'Há 3 dias',
  applicants: 45,
  description: `Estamos procurando um Analista de Marketing Digital Sênior para se juntar à nossa equipe dinâmica e inovadora. O candidato ideal terá experiência comprovada em estratégias de marketing digital, SEO, e análise de dados.

Você será responsável por desenvolver e implementar estratégias de marketing digital que aumentem o engajamento e conversão de clientes. Trabalhará em estreita colaboração com as equipes de produto, vendas e design.`,
  responsibilities: [
    'Desenvolver e implementar estratégias de marketing digital',
    'Gerenciar campanhas de SEO e SEM',
    'Analisar métricas e KPIs de performance',
    'Criar relatórios de desempenho e apresentar insights',
    'Colaborar com equipes multifuncionais',
    'Otimizar funis de conversão e jornadas do cliente'
  ],
  requirements: [
    '5+ anos de experiência em marketing digital',
    'Conhecimento avançado de Google Ads e Analytics',
    'Experiência com SEO e SEM',
    'Habilidades analíticas e conhecimento de métricas',
    'Excelente comunicação escrita e verbal',
    'Graduação em Marketing, Comunicação ou áreas relacionadas'
  ],
  benefits: [
    'Plano de saúde e odontológico',
    'Vale refeição e alimentação',
    'Home office flexível',
    'Programa de desenvolvimento profissional',
    'Bônus por desempenho',
    'Gympass'
  ],
  requiredSkills: [
    { name: 'Marketing Digital', match: true },
    { name: 'SEO', match: true },
    { name: 'Google Ads', match: true },
    { name: 'Analytics', match: false },
    { name: 'Google Analytics', match: false },
    { name: 'Facebook Ads', match: false }
  ]
};

export function JobDetail({ jobId, user, onBack, onNavigate, onLogout }: JobDetailProps) {
  const job = jobData;

  const userMatchedSkills = job.requiredSkills.filter(s => s.match).length;
  const totalSkills = job.requiredSkills.length;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage="jobs"
        onNavigate={onNavigate}
        onLogout={onLogout}
        user={user}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar para vagas
        </button>

        {/* Job Header */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 md:p-8 mb-6">
          <div className="flex flex-col md:flex-row items-start gap-6 mb-6">
            <img
              src={job.logo}
              alt={job.company}
              className="w-20 h-20 rounded-xl object-cover"
            />
            <div className="flex-1">
              <h1 className="text-gray-900 mb-2">{job.title}</h1>
              <p className="text-gray-600 mb-4">{job.company}</p>

              <div className="flex flex-wrap gap-4 text-gray-600 mb-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  <span>{job.salary}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  <span>{job.type}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{job.postedDate}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>{job.applicants} candidatos</span>
                </div>
              </div>

              <div className="px-4 py-3 bg-green-50 border border-green-200 rounded-lg inline-flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span className="text-green-900">{job.match}% de compatibilidade com seu perfil</span>
              </div>
            </div>
          </div>

          <button className="w-full md:w-auto px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
            Candidatar-se a esta vaga
          </button>
        </div>

        {/* Skills Match */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Compatibilidade de Habilidades</h2>
          <div className="mb-4">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">
                Você possui {userMatchedSkills} de {totalSkills} habilidades requeridas
              </span>
              <span className="text-purple-600">{Math.round((userMatchedSkills / totalSkills) * 100)}%</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-600 to-blue-600 rounded-full"
                style={{ width: `${(userMatchedSkills / totalSkills) * 100}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {job.requiredSkills.map((skill, i) => (
              <div
                key={i}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                  skill.match
                    ? 'bg-green-50 border border-green-200'
                    : 'bg-gray-50 border border-gray-200'
                }`}
              >
                {skill.match ? (
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                ) : (
                  <XCircle className="w-5 h-5 text-gray-400" />
                )}
                <span className={skill.match ? 'text-green-900' : 'text-gray-600'}>
                  {skill.name}
                </span>
              </div>
            ))}
          </div>

          {userMatchedSkills < totalSkills && (
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-blue-900 mb-2">💡 Dica: Aprimore suas habilidades</p>
              <p className="text-blue-700">
                Confira nossos cursos recomendados para desenvolver as habilidades que faltam e aumentar suas chances!
              </p>
            </div>
          )}
        </div>

        {/* Job Description */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Sobre a vaga</h2>
          <p className="text-gray-700 whitespace-pre-line">{job.description}</p>
        </div>

        {/* Responsibilities */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Responsabilidades</h2>
          <ul className="space-y-2">
            {job.responsibilities.map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-gray-700">
                <CheckCircle2 className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Requirements */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Requisitos</h2>
          <ul className="space-y-2">
            {job.requirements.map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-gray-700">
                <CheckCircle2 className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Benefits */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Benefícios</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {job.benefits.map((benefit, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3 bg-purple-50 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-purple-600" />
                <span className="text-gray-700">{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Apply Button */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-gray-900 mb-1">Pronto para se candidatar?</h3>
              <p className="text-gray-600">
                Envie sua candidatura e destaque-se dos demais candidatos
              </p>
            </div>
            <button className="w-full md:w-auto px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap">
              Candidatar-se agora
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
