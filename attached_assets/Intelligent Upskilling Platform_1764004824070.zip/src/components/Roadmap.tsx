import { User } from '../App';
import { CheckCircle2, Circle, Lock } from 'lucide-react';

type RoadmapProps = {
  user: User;
};

const roadmapSteps = [
  {
    id: '1',
    title: 'Fundamentos de Análise de Dados',
    description: 'Aprenda os conceitos básicos de análise de dados e estatística',
    status: 'completed',
    duration: '4 semanas',
    skills: ['Excel', 'Estatística Básica', 'SQL']
  },
  {
    id: '2',
    title: 'Python para Dados',
    description: 'Domine Python e bibliotecas essenciais como Pandas e NumPy',
    status: 'in-progress',
    duration: '8 semanas',
    progress: 65,
    skills: ['Python', 'Pandas', 'NumPy']
  },
  {
    id: '3',
    title: 'Visualização de Dados',
    description: 'Crie visualizações impactantes com ferramentas modernas',
    status: 'available',
    duration: '6 semanas',
    skills: ['Tableau', 'Power BI', 'Data Viz']
  },
  {
    id: '4',
    title: 'Machine Learning Básico',
    description: 'Introdução aos conceitos e algoritmos de ML',
    status: 'locked',
    duration: '10 semanas',
    skills: ['ML', 'Scikit-learn', 'Algorithms']
  },
  {
    id: '5',
    title: 'Projetos Práticos',
    description: 'Aplique seus conhecimentos em projetos reais',
    status: 'locked',
    duration: '12 semanas',
    skills: ['Portfolio', 'Real Projects']
  }
];

export function Roadmap({ user }: RoadmapProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <div className="space-y-6">
        {roadmapSteps.map((step, index) => {
          const isCompleted = step.status === 'completed';
          const isInProgress = step.status === 'in-progress';
          const isLocked = step.status === 'locked';
          
          return (
            <div key={step.id} className="relative">
              {/* Connector Line */}
              {index < roadmapSteps.length - 1 && (
                <div className="absolute left-5 top-12 w-0.5 h-16 bg-gray-200" />
              )}
              
              <div className={`flex gap-4 ${isLocked ? 'opacity-50' : ''}`}>
                {/* Status Icon */}
                <div className="flex-shrink-0">
                  {isCompleted && (
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-green-600" />
                    </div>
                  )}
                  {isInProgress && (
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center relative">
                      <Circle className="w-6 h-6 text-purple-600" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-3 h-3 bg-purple-600 rounded-full animate-pulse" />
                      </div>
                    </div>
                  )}
                  {step.status === 'available' && (
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Circle className="w-6 h-6 text-blue-600" />
                    </div>
                  )}
                  {isLocked && (
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <Lock className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 pb-4">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <h3 className="text-gray-900 mb-1">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                    <span className="text-gray-500 whitespace-nowrap">{step.duration}</span>
                  </div>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {step.skills.map((skill, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* Progress Bar */}
                  {isInProgress && step.progress && (
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Progresso</span>
                        <span className="text-purple-600">{step.progress}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-purple-600 to-blue-600 rounded-full transition-all"
                          style={{ width: `${step.progress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Status Badge */}
                  <div className="mt-3">
                    {isCompleted && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full">
                        <CheckCircle2 className="w-4 h-4" />
                        Concluído
                      </span>
                    )}
                    {isInProgress && (
                      <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                        Continuar estudando
                      </button>
                    )}
                    {step.status === 'available' && (
                      <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        Iniciar módulo
                      </button>
                    )}
                    {isLocked && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-500 rounded-full">
                        <Lock className="w-4 h-4" />
                        Bloqueado
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
