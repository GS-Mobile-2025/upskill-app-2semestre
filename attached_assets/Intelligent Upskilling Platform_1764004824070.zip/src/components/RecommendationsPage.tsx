import { Navigation } from './Navigation';
import { Page, User } from '../App';
import { CourseCard } from './CourseCard';
import { Sparkles, TrendingUp, Target, Brain } from 'lucide-react';

type RecommendationsPageProps = {
  user: User;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
};

const recommendedCourses = [
  {
    id: '1',
    title: 'Python para Análise de Dados',
    provider: 'Coursera',
    duration: '8 semanas',
    level: 'Intermediário',
    match: 92,
    image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=300&fit=crop',
    skills: ['Python', 'Pandas', 'Data Analysis']
  },
  {
    id: '2',
    title: 'Machine Learning Fundamentals',
    provider: 'Udacity',
    duration: '12 semanas',
    level: 'Avançado',
    match: 88,
    image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=300&fit=crop',
    skills: ['ML', 'AI', 'Python']
  },
  {
    id: '3',
    title: 'Marketing Digital com IA',
    provider: 'LinkedIn Learning',
    duration: '6 semanas',
    level: 'Iniciante',
    match: 95,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
    skills: ['IA', 'Marketing', 'Analytics']
  },
  {
    id: '4',
    title: 'Google Analytics 4 Completo',
    provider: 'Google',
    duration: '4 semanas',
    level: 'Intermediário',
    match: 90,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
    skills: ['Analytics', 'Google Analytics', 'Data']
  },
  {
    id: '5',
    title: 'Facebook & Instagram Ads',
    provider: 'Meta',
    duration: '5 semanas',
    level: 'Intermediário',
    match: 87,
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=300&fit=crop',
    skills: ['Social Media', 'Ads', 'Marketing']
  },
  {
    id: '6',
    title: 'Content Marketing Strategy',
    provider: 'HubSpot',
    duration: '6 semanas',
    level: 'Intermediário',
    match: 85,
    image: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?w=400&h=300&fit=crop',
    skills: ['Content', 'Marketing', 'Strategy']
  }
];

const insights = [
  {
    icon: TrendingUp,
    color: 'purple',
    title: 'Tendência de Mercado',
    description: 'Profissionais com habilidades em IA estão em alta demanda, com aumento de 150% nas vagas nos últimos 6 meses.'
  },
  {
    icon: Target,
    color: 'blue',
    title: 'Suas Lacunas de Habilidades',
    description: 'Desenvolver conhecimentos em Python e Machine Learning pode aumentar seu match em 15-20% nas vagas de interesse.'
  },
  {
    icon: Brain,
    color: 'green',
    title: 'Recomendação IA',
    description: 'Com base no seu perfil, cursos de análise de dados combinados com suas habilidades de marketing podem abrir novas oportunidades.'
  }
];

export function RecommendationsPage({ user, onNavigate, onLogout }: RecommendationsPageProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage="recommendations"
        onNavigate={onNavigate}
        onLogout={onLogout}
        user={user}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-gray-900">Recomendações Personalizadas</h1>
          </div>
          <p className="text-gray-600">
            Nossa IA analisou seu perfil e selecionou os melhores cursos e insights para você
          </p>
        </div>

        {/* AI Insights */}
        <div className="mb-8">
          <h2 className="text-gray-900 mb-4">Insights da IA</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {insights.map((insight, i) => {
              const Icon = insight.icon;
              const colorClasses = {
                purple: 'bg-purple-100 text-purple-600',
                blue: 'bg-blue-100 text-blue-600',
                green: 'bg-green-100 text-green-600'
              }[insight.color];

              return (
                <div key={i} className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className={`w-12 h-12 ${colorClasses} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-gray-900 mb-2">{insight.title}</h3>
                  <p className="text-gray-600">{insight.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recommended Courses */}
        <div className="mb-8">
          <h2 className="text-gray-900 mb-4">Cursos Recomendados para Você</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>

        {/* Career Path Suggestion */}
        <div className="bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl p-8 text-white">
          <h2 className="mb-4">Sugestão de Carreira</h2>
          <p className="mb-6 text-purple-50">
            Com base no seu perfil atual em {user.role} e tendências de mercado, identificamos uma
            oportunidade de transição para <span>Analista de Marketing de Dados</span>.
            Esta carreira combina suas habilidades de marketing com análise de dados e está em alta demanda.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="px-6 py-3 bg-white text-purple-600 rounded-lg hover:bg-purple-50 transition-colors">
              Ver trilha completa
            </button>
            <button className="px-6 py-3 bg-purple-700 text-white rounded-lg hover:bg-purple-800 transition-colors">
              Falar com um mentor
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
