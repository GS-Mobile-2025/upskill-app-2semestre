import { MapPin, DollarSign, TrendingUp, Briefcase } from 'lucide-react';

type Job = {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  match: number;
  logo: string;
  skills: string[];
};

type JobCardProps = {
  job: Job;
  onViewJob: (jobId: string) => void;
};

export function JobCard({ job, onViewJob }: JobCardProps) {
  return (
    <div
      onClick={() => onViewJob(job.id)}
      className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex items-start gap-4 mb-4">
        <img
          src={job.logo}
          alt={job.company}
          className="w-12 h-12 rounded-lg object-cover"
        />
        <div className="flex-1">
          <h3 className="text-gray-900 mb-1">{job.title}</h3>
          <p className="text-gray-600">{job.company}</p>
        </div>
        <div className="px-3 py-1 bg-green-50 border border-green-200 rounded-full flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-600" />
          <span className="text-green-600">{job.match}%</span>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-gray-600">
          <MapPin className="w-4 h-4" />
          <span>{job.location}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <DollarSign className="w-4 h-4" />
          <span>{job.salary}</span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {job.skills.map((skill, i) => (
          <span
            key={i}
            className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full"
          >
            {skill}
          </span>
        ))}
      </div>

      <button className="w-full py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center gap-2">
        <Briefcase className="w-4 h-4" />
        Ver detalhes da vaga
      </button>
    </div>
  );
}
