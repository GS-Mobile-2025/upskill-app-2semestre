import { Navigation } from './Navigation';
import { Page, User } from '../App';
import { Roadmap } from './Roadmap';
import { CourseCard } from './CourseCard';
import { JobCard } from './JobCard';
import { TrendingUp, BookOpen, Briefcase } from 'lucide-react';

type DashboardProps = {
  user: User;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  onViewJob: (jobId: string) => void;
};

const mockCourses = [
  {
    id: '1',
    title: 'Python para Análise de Dados',
    provider: 'Coursera',
    duration: '8 semanas',
    level: 'Intermediário',
    match: 92,
    image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=300&fit=crop',
    skills: ['Python', 'Pandas', 'Data Analysis']
  },
  {
    id: '2',
    title: 'Machine Learning Fundamentals',
    provider: 'Udacity',
    duration: '12 semanas',
    level: 'Avançado',
    match: 88,
    image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=300&fit=crop',
    skills: ['ML', 'AI', 'Python']
  },
  {
    id: '3',
    title: 'Marketing Digital com IA',
    provider: 'LinkedIn Learning',
    duration: '6 semanas',
    level: 'Iniciante',
    match: 95,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
    skills: ['IA', 'Marketing', 'Analytics']
  }
];

const mockJobs = [
  {
    id: '1',
    title: 'Analista de Marketing Digital Sênior',
    company: 'Tech Solutions',
    location: 'São Paulo, SP',
    salary: 'R$ 8.000 - R$ 12.000',
    match: 87,
    logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop',
    skills: ['Marketing Digital', 'SEO', 'Google Ads', 'Analytics']
  },
  {
    id: '2',
    title: 'Especialista em Growth Marketing',
    company: 'StartupXYZ',
    location: 'Remoto',
    salary: 'R$ 10.000 - R$ 15.000',
    match: 82,
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop',
    skills: ['Growth Hacking', 'SEO', 'Marketing', 'Analytics']
  }
];

export function Dashboard({ user, onNavigate, onLogout, onViewJob }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage="dashboard"
        onNavigate={onNavigate}
        onLogout={onLogout}
        user={user}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Olá, {user.name}! 👋</h1>
          <p className="text-gray-600">
            Continue sua jornada de aprendizado e descubra novas oportunidades
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <span className="text-gray-600">Progresso Geral</span>
            </div>
            <p className="text-gray-900">68%</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-gray-600">Cursos em Andamento</span>
            </div>
            <p className="text-gray-900">3 cursos</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-gray-600">Vagas Compatíveis</span>
            </div>
            <p className="text-gray-900">24 vagas</p>
          </div>
        </div>

        {/* Roadmap */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-900">Seu Roadmap de Aprendizado</h2>
          </div>
          <Roadmap user={user} />
        </div>

        {/* Recommended Courses */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-900">Cursos Recomendados</h2>
            <button
              onClick={() => onNavigate('recommendations')}
              className="text-purple-600 hover:text-purple-700"
            >
              Ver todos
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>

        {/* Top Matching Jobs */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-900">Vagas Compatíveis</h2>
            <button
              onClick={() => onNavigate('jobs')}
              className="text-purple-600 hover:text-purple-700"
            >
              Ver todas
            </button>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockJobs.map((job) => (
              <JobCard key={job.id} job={job} onViewJob={onViewJob} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
