import { Clock, TrendingUp } from 'lucide-react';

type Course = {
  id: string;
  title: string;
  provider: string;
  duration: string;
  level: string;
  match: number;
  image: string;
  skills: string[];
};

type CourseCardProps = {
  course: Course;
};

export function CourseCard({ course }: CourseCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
      <div className="relative h-40 overflow-hidden">
        <img
          src={course.image}
          alt={course.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3 px-3 py-1 bg-white rounded-full flex items-center gap-1">
          <TrendingUp className="w-4 h-4 text-green-600" />
          <span className="text-green-600">{course.match}% match</span>
        </div>
      </div>

      <div className="p-4">
        <div className="mb-2">
          <span className="text-purple-600">{course.provider}</span>
          <h3 className="text-gray-900 mb-1">{course.title}</h3>
        </div>

        <div className="flex items-center gap-4 text-gray-600 mb-3">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration}</span>
          </div>
          <span className="px-2 py-1 bg-gray-100 rounded text-gray-700">
            {course.level}
          </span>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {course.skills.map((skill, i) => (
            <span
              key={i}
              className="px-2 py-1 bg-purple-50 text-purple-700 rounded"
            >
              {skill}
            </span>
          ))}
        </div>

        <button className="w-full py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          Ver curso
        </button>
      </div>
    </div>
  );
}
