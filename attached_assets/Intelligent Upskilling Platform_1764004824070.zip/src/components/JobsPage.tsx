import { Navigation } from './Navigation';
import { Page, User } from '../App';
import { JobCard } from './JobCard';
import { Search, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';

type JobsPageProps = {
  user: User;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  onViewJob: (jobId: string) => void;
};

const allJobs = [
  {
    id: '1',
    title: 'Analista de Marketing Digital Sênior',
    company: 'Tech Solutions',
    location: 'São Paulo, SP',
    salary: 'R$ 8.000 - R$ 12.000',
    match: 87,
    logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop',
    skills: ['Marketing Digital', 'SEO', 'Google Ads', 'Analytics']
  },
  {
    id: '2',
    title: 'Especialista em Growth Marketing',
    company: 'StartupXYZ',
    location: 'Remoto',
    salary: 'R$ 10.000 - R$ 15.000',
    match: 82,
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop',
    skills: ['Growth Hacking', 'SEO', 'Marketing', 'Analytics']
  },
  {
    id: '3',
    title: 'Coordenador de Marketing',
    company: 'E-commerce Brasil',
    location: 'Rio de Janeiro, RJ',
    salary: 'R$ 7.000 - R$ 10.000',
    match: 78,
    logo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=100&h=100&fit=crop',
    skills: ['Marketing', 'E-commerce', 'Redes Sociais']
  },
  {
    id: '4',
    title: 'Analista de Dados de Marketing',
    company: 'Data Insights',
    location: 'São Paulo, SP',
    salary: 'R$ 9.000 - R$ 13.000',
    match: 85,
    logo: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=100&h=100&fit=crop',
    skills: ['Analytics', 'Python', 'SQL', 'Marketing']
  },
  {
    id: '5',
    title: 'Gerente de Marketing Digital',
    company: 'Agência Criativa',
    location: 'Belo Horizonte, MG',
    salary: 'R$ 12.000 - R$ 18.000',
    match: 75,
    logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=100&h=100&fit=crop',
    skills: ['Marketing', 'Gestão', 'SEO', 'Redes Sociais']
  },
  {
    id: '6',
    title: 'Social Media Manager',
    company: 'Influencer Hub',
    location: 'Remoto',
    salary: 'R$ 6.000 - R$ 9.000',
    match: 80,
    logo: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=100&h=100&fit=crop',
    skills: ['Redes Sociais', 'Marketing', 'Content Creation']
  }
];

export function JobsPage({ user, onNavigate, onLogout, onViewJob }: JobsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const filteredJobs = allJobs.filter(job =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage="jobs"
        onNavigate={onNavigate}
        onLogout={onLogout}
        user={user}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Vagas Compatíveis</h1>
          <p className="text-gray-600">
            {filteredJobs.length} vagas encontradas baseadas no seu perfil
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar vagas, empresas ou habilidades..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <SlidersHorizontal className="w-5 h-5" />
            Filtros
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8">
            <h3 className="text-gray-900 mb-4">Filtros</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block mb-2 text-gray-700">Localização</label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option>Todas as localizações</option>
                  <option>Remoto</option>
                  <option>São Paulo, SP</option>
                  <option>Rio de Janeiro, RJ</option>
                  <option>Belo Horizonte, MG</option>
                </select>
              </div>
              <div>
                <label className="block mb-2 text-gray-700">Faixa Salarial</label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option>Todas as faixas</option>
                  <option>Até R$ 5.000</option>
                  <option>R$ 5.000 - R$ 10.000</option>
                  <option>R$ 10.000 - R$ 15.000</option>
                  <option>Acima de R$ 15.000</option>
                </select>
              </div>
              <div>
                <label className="block mb-2 text-gray-700">Match Mínimo</label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option>Qualquer</option>
                  <option>70%+</option>
                  <option>80%+</option>
                  <option>90%+</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Jobs Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredJobs.map((job) => (
            <JobCard key={job.id} job={job} onViewJob={onViewJob} />
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">Nenhuma vaga encontrada com esses critérios.</p>
          </div>
        )}
      </div>
    </div>
  );
}
