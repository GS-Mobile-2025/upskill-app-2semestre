import { Navigation } from './Navigation';
import { Page, User } from '../App';
import { Edit2, Award, Briefcase, Calendar } from 'lucide-react';
import { useState } from 'react';

type ProfileProps = {
  user: User;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
};

export function Profile({ user, onNavigate, onLogout, onUpdateUser }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(user);

  const handleSave = () => {
    onUpdateUser(editedUser);
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage="profile"
        onNavigate={onNavigate}
        onLogout={onLogout}
        user={user}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="bg-white rounded-xl border border-gray-200 p-8 mb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center overflow-hidden">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-white">{user.name.charAt(0)}</span>
              )}
            </div>

            <div className="flex-1">
              <div className="flex items-start justify-between gap-4 mb-2">
                <div>
                  <h1 className="text-gray-900 mb-1">{user.name}</h1>
                  <p className="text-gray-600">{user.role}</p>
                </div>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  {isEditing ? 'Cancelar' : 'Editar Perfil'}
                </button>
              </div>
              <p className="text-gray-600">{user.bio}</p>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        {isEditing && (
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <h2 className="text-gray-900 mb-4">Editar Informações</h2>
            <div className="space-y-4">
              <div>
                <label className="block mb-2 text-gray-700">Nome</label>
                <input
                  type="text"
                  value={editedUser.name}
                  onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-gray-700">Cargo Atual</label>
                <input
                  type="text"
                  value={editedUser.role}
                  onChange={(e) => setEditedUser({ ...editedUser, role: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block mb-2 text-gray-700">Bio</label>
                <textarea
                  value={editedUser.bio}
                  onChange={(e) => setEditedUser({ ...editedUser, bio: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Award className="w-5 h-5 text-purple-600" />
              </div>
              <span className="text-gray-600">Cursos Concluídos</span>
            </div>
            <p className="text-gray-900">12 cursos</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-gray-600">Anos de Experiência</span>
            </div>
            <p className="text-gray-900">{user.experience} anos</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-gray-600">Membro desde</span>
            </div>
            <p className="text-gray-900">Jan 2024</p>
          </div>
        </div>

        {/* Skills */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-gray-900 mb-4">Minhas Habilidades</h2>
          <div className="flex flex-wrap gap-3">
            {user.skills.map((skill, i) => (
              <span
                key={i}
                className="px-4 py-2 bg-purple-50 border border-purple-200 text-purple-700 rounded-lg"
              >
                {skill}
              </span>
            ))}
            <button className="px-4 py-2 border-2 border-dashed border-gray-300 text-gray-600 rounded-lg hover:border-purple-400 hover:text-purple-600 transition-colors">
              + Adicionar habilidade
            </button>
          </div>
        </div>

        {/* Certificates */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-gray-900 mb-4">Certificados</h2>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-gray-900 mb-1">Marketing Digital Avançado</h3>
                <p className="text-gray-600">Google Digital Academy</p>
                <p className="text-gray-500">Emitido em Março 2024</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Award className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-gray-900 mb-1">SEO Specialist</h3>
                <p className="text-gray-600">HubSpot Academy</p>
                <p className="text-gray-500">Emitido em Janeiro 2024</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
